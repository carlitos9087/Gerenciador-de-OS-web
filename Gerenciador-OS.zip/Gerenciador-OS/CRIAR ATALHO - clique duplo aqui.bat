@echo off
:: ============================================================
::  CLIQUE DUPLO NESTE ARQUIVO para criar o atalho
::  Mantenha este .bat na mesma pasta que o .exe e o .ps1
:: ============================================================
PowerShell -ExecutionPolicy Bypass -NoProfile -File "%~dp0criar-atalho.ps1"
