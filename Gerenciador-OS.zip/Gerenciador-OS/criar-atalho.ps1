# =============================================================
#  criar-atalho.ps1
#  Fica em: Gerenciador-OS\
#  EXE e imagens ficam em: Gerenciador-OS\net8.0-windows\
# =============================================================

# --- Configurações -----------------------------------------------------------
$nomeExe      = "Gerenciador-de-Ordens-de_servico.exe"
$nomeAtalho   = "Gerenciador de Ordens de Serviço"
$arquivoIcone = "icone OS.png"   # troque pelo nome da imagem desejada
# -----------------------------------------------------------------------------

Add-Type -AssemblyName System.Drawing

# Pasta do script  → Gerenciador-OS\
$pastaScript = Split-Path -Parent $MyInvocation.MyCommand.Definition

# Pasta do EXE    → Gerenciador-OS\net8.0-windows\
$pastaExe = Join-Path $pastaScript "net8.0-windows"

$caminhoExe   = Join-Path $pastaExe $nomeExe
$caminhoPng   = Join-Path $pastaExe $arquivoIcone
$caminhoIco   = Join-Path $pastaExe "icone_app.ico"
$areaTrabalho = [Environment]::GetFolderPath("Desktop")
$caminhoLnk   = Join-Path $areaTrabalho "$nomeAtalho.lnk"

# --- Validações --------------------------------------------------------------
if (-not (Test-Path $caminhoExe)) {
    Write-Host "ERRO: Executavel nao encontrado em:" -ForegroundColor Red
    Write-Host "      $caminhoExe" -ForegroundColor Red
    Read-Host "Pressione ENTER para sair"
    exit 1
}

if (-not (Test-Path $caminhoPng)) {
    Write-Host "ERRO: Imagem '$arquivoIcone' nao encontrada em:" -ForegroundColor Red
    Write-Host "      $caminhoPng" -ForegroundColor Red
    Read-Host "Pressione ENTER para sair"
    exit 1
}

# --- Remove arquivos antigos para forçar regeneração -------------------------
Write-Host "Removendo arquivos antigos..." -ForegroundColor Yellow

if (Test-Path $caminhoIco) {
    Remove-Item -Path $caminhoIco -Force
    Write-Host "  icone_app.ico removido." -ForegroundColor DarkYellow
}
if (Test-Path $caminhoLnk) {
    Remove-Item -Path $caminhoLnk -Force
    Write-Host "  Atalho antigo removido." -ForegroundColor DarkYellow
}

# --- Converter PNG -> ICO -----------------------------------------------------
Write-Host ""
Write-Host "Convertendo '$arquivoIcone' para ICO..." -ForegroundColor Cyan

function ConvertTo-Ico {
    param([string]$PngPath, [string]$IcoPath)

    $sizes   = @(256, 64, 48, 32, 16)
    $bitmaps = @()

    foreach ($size in $sizes) {
        $bmp = New-Object System.Drawing.Bitmap($size, $size)
        $g   = [System.Drawing.Graphics]::FromImage($bmp)
        $g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
        $g.SmoothingMode     = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
        $src = [System.Drawing.Image]::FromFile($PngPath)
        $g.DrawImage($src, 0, 0, $size, $size)
        $src.Dispose()
        $g.Dispose()
        $bitmaps += $bmp
    }

    $ms      = New-Object System.IO.MemoryStream
    $writer  = New-Object System.IO.BinaryWriter($ms)
    $dirSize = 6 + 16 * $bitmaps.Count

    $writer.Write([uint16]0)
    $writer.Write([uint16]1)
    $writer.Write([uint16]$bitmaps.Count)

    $streams = @()
    foreach ($bmp in $bitmaps) {
        $imgStream = New-Object System.IO.MemoryStream
        $bmp.Save($imgStream, [System.Drawing.Imaging.ImageFormat]::Png)
        $streams += $imgStream
    }

    $offset = $dirSize
    for ($i = 0; $i -lt $bitmaps.Count; $i++) {
        $sz  = $sizes[$i]
        $len = $streams[$i].Length
        $w   = if ($sz -ge 256) { 0 } else { [byte]$sz }
        $h   = if ($sz -ge 256) { 0 } else { [byte]$sz }
        $writer.Write([byte]$w)
        $writer.Write([byte]$h)
        $writer.Write([byte]0)
        $writer.Write([byte]0)
        $writer.Write([uint16]1)
        $writer.Write([uint16]32)
        $writer.Write([uint32]$len)
        $writer.Write([uint32]$offset)
        $offset += $len
    }

    foreach ($s in $streams) {
        $s.Seek(0, [System.IO.SeekOrigin]::Begin) | Out-Null
        $s.CopyTo($ms)
        $s.Dispose()
    }
    foreach ($bmp in $bitmaps) { $bmp.Dispose() }

    [System.IO.File]::WriteAllBytes($IcoPath, $ms.ToArray())
    $writer.Dispose()
    $ms.Dispose()
}

ConvertTo-Ico -PngPath $caminhoPng -IcoPath $caminhoIco
Write-Host "ICO criado: $caminhoIco" -ForegroundColor Green

# --- Limpar cache de ícones do Windows ----------------------------------------
Write-Host ""
Write-Host "Limpando cache de icones do Windows..." -ForegroundColor Cyan

$cacheIcones = "$env:LOCALAPPDATA\Microsoft\Windows\Explorer"
Get-ChildItem -Path $cacheIcones -Filter "iconcache*" -ErrorAction SilentlyContinue | ForEach-Object {
    try {
        Remove-Item $_.FullName -Force -ErrorAction Stop
        Write-Host "  Removido: $($_.Name)" -ForegroundColor DarkYellow
    } catch {
        Write-Host "  (Em uso, limpo no proximo reinicio): $($_.Name)" -ForegroundColor DarkGray
    }
}

# --- Criar atalho -------------------------------------------------------------
Write-Host ""
Write-Host "Criando atalho na Area de Trabalho..." -ForegroundColor Cyan

$wsh    = New-Object -ComObject WScript.Shell
$atalho = $wsh.CreateShortcut($caminhoLnk)

$atalho.TargetPath       = $caminhoExe
$atalho.WorkingDirectory = $pastaExe       # WorkingDir aponta para net8.0-windows
$atalho.Description      = $nomeAtalho
$atalho.WindowStyle      = 1
$atalho.IconLocation     = "$caminhoIco,0"
$atalho.Save()

# --- Forçar atualização da área de trabalho -----------------------------------
$code = @"
using System;
using System.Runtime.InteropServices;
public class Shell32 {
    [DllImport("shell32.dll")]
    public static extern void SHChangeNotify(int eventId, int flags, IntPtr item1, IntPtr item2);
}
"@
Add-Type -TypeDefinition $code -ErrorAction SilentlyContinue
[Shell32]::SHChangeNotify(0x8000000, 0x1000, [IntPtr]::Zero, [IntPtr]::Zero)

Write-Host ""
Write-Host "=====================================" -ForegroundColor Green
Write-Host " Atalho criado com sucesso!"           -ForegroundColor Green
Write-Host " Icone : $arquivoIcone"                -ForegroundColor White
Write-Host " Atalho: $caminhoLnk"                  -ForegroundColor White
Write-Host "=====================================" -ForegroundColor Green
Write-Host ""
Write-Host "Se o icone antigo ainda aparecer:" -ForegroundColor DarkGray
Write-Host "Botao direito na Area de Trabalho > Atualizar" -ForegroundColor DarkGray
Write-Host ""
Read-Host "Pressione ENTER para sair"