# =============================================================
#  criar-atalho.ps1
#  Cria um atalho na Área de Trabalho com ícone personalizado
#  Coloque este arquivo na mesma pasta que o .exe
# =============================================================

# --- Configurações -----------------------------------------------------------
$nomeExe        = "Gerenciador-de-Ordens-de_servico.exe"
$nomeAtalho     = "Gerenciador de Ordens de Serviço"   # nome que aparece no atalho
$arquivoIcone   = "icone OS.png"                           # troque por "hide.png" se preferir
# -----------------------------------------------------------------------------

Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.Windows.Forms

# Pasta onde o script está (mesma pasta do .exe)
$pastaBase = Split-Path -Parent $MyInvocation.MyCommand.Definition

$caminhoExe   = Join-Path $pastaBase $nomeExe
$caminhoPng   = Join-Path $pastaBase $arquivoIcone
$caminhoIco   = Join-Path $pastaBase "icone_app.ico"
$areaTrabalho = [Environment]::GetFolderPath("Desktop")
$caminhoLnk   = Join-Path $areaTrabalho "$nomeAtalho.lnk"

# --- Validações --------------------------------------------------------------
if (-not (Test-Path $caminhoExe)) {
    Write-Host "ERRO: Executavel nao encontrado em: $caminhoExe" -ForegroundColor Red
    Read-Host "Pressione ENTER para sair"
    exit 1
}

if (-not (Test-Path $caminhoPng)) {
    Write-Host "ERRO: Imagem '$arquivoIcone' nao encontrada em: $caminhoPng" -ForegroundColor Red
    Read-Host "Pressione ENTER para sair"
    exit 1
}

# --- FORÇA exclusão do .ico e do atalho antigos ------------------------------
Write-Host "Removendo arquivos antigos..." -ForegroundColor Yellow

if (Test-Path $caminhoIco) {
    Remove-Item -Path $caminhoIco -Force
    Write-Host "  icone_app.ico removido." -ForegroundColor DarkYellow
}
if (Test-Path $caminhoLnk) {
    Remove-Item -Path $caminhoLnk -Force
    Write-Host "  Atalho antigo removido." -ForegroundColor DarkYellow
}

# --- Converter PNG -> ICO (múltiplos tamanhos: 256, 64, 48, 32, 16) ---------
Write-Host ""
Write-Host "Convertendo '$arquivoIcone' para ICO..." -ForegroundColor Cyan

function ConvertTo-Ico {
    param([string]$PngPath, [string]$IcoPath)

    $sizes   = @(256, 64, 48, 32, 16)
    $bitmaps = @()

    foreach ($size in $sizes) {
        $bmp = New-Object System.Drawing.Bitmap($size, $size)
        $g   = [System.Drawing.Graphics]::FromImage($bmp)
        $g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
        $g.SmoothingMode     = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
        $src = [System.Drawing.Image]::FromFile($PngPath)
        $g.DrawImage($src, 0, 0, $size, $size)
        $src.Dispose()
        $g.Dispose()
        $bitmaps += $bmp
    }

    $ms      = New-Object System.IO.MemoryStream
    $writer  = New-Object System.IO.BinaryWriter($ms)
    $dirSize = 6 + 16 * $bitmaps.Count

    # ICO Header
    $writer.Write([uint16]0)
    $writer.Write([uint16]1)
    $writer.Write([uint16]$bitmaps.Count)

    $streams = @()
    foreach ($bmp in $bitmaps) {
        $imgStream = New-Object System.IO.MemoryStream
        $bmp.Save($imgStream, [System.Drawing.Imaging.ImageFormat]::Png)
        $streams += $imgStream
    }

    $offset = $dirSize
    for ($i = 0; $i -lt $bitmaps.Count; $i++) {
        $sz  = $sizes[$i]
        $len = $streams[$i].Length
        $w   = if ($sz -ge 256) { 0 } else { [byte]$sz }
        $h   = if ($sz -ge 256) { 0 } else { [byte]$sz }
        $writer.Write([byte]$w)
        $writer.Write([byte]$h)
        $writer.Write([byte]0)
        $writer.Write([byte]0)
        $writer.Write([uint16]1)
        $writer.Write([uint16]32)
        $writer.Write([uint32]$len)
        $writer.Write([uint32]$offset)
        $offset += $len
    }

    foreach ($s in $streams) {
        $s.Seek(0, [System.IO.SeekOrigin]::Begin) | Out-Null
        $s.CopyTo($ms)
        $s.Dispose()
    }
    foreach ($bmp in $bitmaps) { $bmp.Dispose() }

    [System.IO.File]::WriteAllBytes($IcoPath, $ms.ToArray())
    $writer.Dispose()
    $ms.Dispose()
}

ConvertTo-Ico -PngPath $caminhoPng -IcoPath $caminhoIco
Write-Host "ICO criado: $caminhoIco" -ForegroundColor Green

# --- Limpar cache de ícones do Windows ---------------------------------------
Write-Host ""
Write-Host "Limpando cache de icones do Windows..." -ForegroundColor Cyan

$cacheIcones = "$env:LOCALAPPDATA\Microsoft\Windows\Explorer"
Get-ChildItem -Path $cacheIcones -Filter "iconcache*" -ErrorAction SilentlyContinue | ForEach-Object {
    try {
        Remove-Item $_.FullName -Force -ErrorAction Stop
        Write-Host "  Removido: $($_.Name)" -ForegroundColor DarkYellow
    } catch {
        Write-Host "  (Em uso, sera limpo no proximo reinicio): $($_.Name)" -ForegroundColor DarkGray
    }
}

# --- Criar o atalho ----------------------------------------------------------
Write-Host ""
Write-Host "Criando atalho na Area de Trabalho..." -ForegroundColor Cyan

$wsh    = New-Object -ComObject WScript.Shell
$atalho = $wsh.CreateShortcut($caminhoLnk)

$atalho.TargetPath       = $caminhoExe
$atalho.WorkingDirectory = $pastaBase
$atalho.Description      = $nomeAtalho
$atalho.WindowStyle      = 1
$atalho.IconLocation     = "$caminhoIco,0"
$atalho.Save()

# --- Forçar atualização da área de trabalho ----------------------------------
$code = @"
using System;
using System.Runtime.InteropServices;
public class Shell32 {
    [DllImport("shell32.dll")]
    public static extern void SHChangeNotify(int eventId, int flags, IntPtr item1, IntPtr item2);
}
"@
Add-Type -TypeDefinition $code -ErrorAction SilentlyContinue
[Shell32]::SHChangeNotify(0x8000000, 0x1000, [IntPtr]::Zero, [IntPtr]::Zero)

Write-Host ""
Write-Host "=====================================" -ForegroundColor Green
Write-Host " Atalho criado com sucesso!" -ForegroundColor Green
Write-Host " Icone usado: $arquivoIcone" -ForegroundColor White
Write-Host " Local: $caminhoLnk" -ForegroundColor White
Write-Host "=====================================" -ForegroundColor Green
Write-Host ""
Write-Host "Se o icone antigo ainda aparecer, clique com o botao" -ForegroundColor DarkGray
Write-Host "direito na Area de Trabalho > Atualizar." -ForegroundColor DarkGray
Write-Host ""
Read-Host "Pressione ENTER para sair"
